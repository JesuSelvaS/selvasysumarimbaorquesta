<!DOCTYPE html>
<html lang="es-MX">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Práctica 1 | Selvas y su Marimba Orquesta</title>

    <link rel="stylesheet" href="{{asset('css/normalize.css')}}">
    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
</head>

<body>
    <header>
        <nav></nav>
    </header>
    <div class="pageContent">
        <section>
            <div class="teamInfo">
                <div class="teamName">
                    <p>Equipo: Selvas y su Marimba Orquesta</p>
                </div>
                <div class="teamMember">
                    <p>Cruz Rodas Edrey Alfredo</p>
                </div>
                <div class="memberInfo">
                    <div class="personalInfo">
                        <article>
                            <h2>Información Básica</h2>
                            <div class="infoItem">
                                <!-- Información básica -->
                                <h3>Personal</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Gustos -->
                                <h3>Gustos</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Hobbies -->
                                <h3>Hobbies</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                        </article>
                    </div>
                    <div class="academicInfo">
                        <article>
                            <h2>Información académica</h2>
                            <div class="infoItem">
                                <!-- Trayectoria -->
                                <h3>Trayectoria</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Área de desempeño -->
                                <h3>Área de desempeño</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Meta -->
                                <h3>Meta</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="teamInfo">
                <div class="teamName">
                    <p>Equipo: Selvas y su Marimba Orquesta</p>
                </div>
                <div class="teamMember">
                    <p>González Ruíz Daniel Alejandro</p>
                </div>
                <div class="memberInfo">
                    <div class="personalInfo">
                        <article>
                            <h2>Información Básica</h2>
                            <div class="infoItem">
                                <!-- Información básica -->
                                <h3>Personal</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Gustos -->
                                <h3>Gustos</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Hobbies -->
                                <h3>Hobbies</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                        </article>
                    </div>
                    <div class="academicInfo">
                        <article>
                            <h2>Información académica</h2>
                            <div class="infoItem">
                                <!-- Trayectoria -->
                                <h3>Trayectoria</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Área de desempeño -->
                                <h3>Área de desempeño</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Meta -->
                                <h3>Meta</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="teamInfo">
                <div class="teamName">
                    <p>Equipo: Selvas y su Marimba Orquesta</p>
                </div>
                <div class="teamMember">
                    <p>Gutiérrez Gutiérrez José Leyder</p>
                </div>
                <div class="memberInfo">
                    <div class="personalInfo">
                        <article>
                            <h2>Información Básica</h2>
                            <div class="infoItem">
                                <!-- Información básica -->
                                <h3>Personal</h3>
                                <ul>
                                    <li>Fecha de nacimiento: 26 de Julio de 1997</li>
                                    <li>Genero: Hombre</li>
                                    <li>Dirección: Terán</li>
                                    <li>Estado civil: Soltero</li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Gustos -->
                                <h3>Gustos</h3>
                                <p>Me gusta trabajar con Bases de Datos asi como programar en C#, además de convivir con mis amigos</p>
                            </div>
                            <div class="infoItem">
                                <!-- Hobbies -->
                                <h3>Hobbies</h3>
                                <p>Jugar Futbol</p>
                            </div>
                        </article>
                    </div>
                    <div class="academicInfo">
                        <article>
                            <h2>Información académica</h2>
                            <div class="infoItem">
                                <!-- Trayectoria -->
                                <h3>Trayectoria</h3>
                                <p>Mi primaria la curse en la escuela Lic. Benito Juarez la cual se encontraba en el pueblo en que nací,
                                    así como la secundaria en la que estudie. Mi preparatoria la curse en un municipio lejos del lugar en el que nací 
                                    y actualmente me encuentro cursando mi licenciatura en el Instituto Tecnológico de Tuxtla Gutiérrez
                                </p>
                            </div>
                            <div class="infoItem">
                                <!-- Área de desempeño -->
                                <h3>Área de desempeño</h3>
                                <p>Ing. Sistemas computacionales</p>
                            </div>
                            <div class="infoItem">
                                <!-- Meta -->
                                <h3>Meta</h3>
                                <p>La meta más sercana que tengo es terminar mi carrera</p>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="teamInfo">
                <div class="teamName">
                    <p>Equipo: Selvas y su Marimba Orquesta</p>
                </div>
                <div class="teamMember">
                    <p>Sánchez Selvas Jesús Alberto</p>
                </div>
                <div class="memberInfo">
                    <div class="personalInfo">
                        <article>
                            <h2>Información Básica</h2>
                            <div class="infoItem">
                                <!-- Información básica -->
                                <h3>Personal</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Gustos -->
                                <h3>Gustos</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Hobbies -->
                                <h3>Hobbies</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                        </article>
                    </div>
                    <div class="academicInfo">
                        <article>
                            <h2>Información académica</h2>
                            <div class="infoItem">
                                <!-- Trayectoria -->
                                <h3>Trayectoria</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Área de desempeño -->
                                <h3>Área de desempeño</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Meta -->
                                <h3>Meta</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="teamInfo">
                <div class="teamName">
                    <p>Equipo: Selvas y su Marimba Orquesta</p>
                </div>
                <div class="teamMember">
                    <p>Sol Santiago Sheyla Valeria</p>
                </div>
                <div class="memberInfo">
                    <div class="personalInfo">
                        <article>
                            <h2>Información Básica</h2>
                            <div class="infoItem">
                                <!-- Información básica -->
                                <h3>Personal</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Gustos -->
                                <h3>Gustos</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Hobbies -->
                                <h3>Hobbies</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                        </article>
                    </div>
                    <div class="academicInfo">
                        <article>
                            <h2>Información académica</h2>
                            <div class="infoItem">
                                <!-- Trayectoria -->
                                <h3>Trayectoria</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Área de desempeño -->
                                <h3>Área de desempeño</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="infoItem">
                                <!-- Meta -->
                                <h3>Meta</h3>
                                <ul>
                                    <li></li>
                                </ul>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </section>
        <section class="info">
            <!-- Etiquetas aside -->
            <div class="asideContent">
                <aside>
                    <h2>Instituto Tecnológico de Tuxtla Gutiérrez</h2>
                    <p>Es una Institución educativa pública de educación superior, que forma parte del Sistema Nacional de Institutos Tecnológicos de México.</p>
                </aside>
                <aside>

                </aside>
            </div>


        </section>
    </div>

    <footer></footer>

    <script type="text/javascript" src="{{asset('js/jquery.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/popper.min.js')}}"></script>
</body>

</html>